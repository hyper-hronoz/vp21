g++ ./MyMenu.cpp ./MyMenuItems.cpp ./lab1.cpp && ./a.out
